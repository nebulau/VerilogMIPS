li $1,2
li $2,3
li $3,5
sw $3,0
sw $3,4
addew $3,$2,$1

lhs $1,0($3)
li $1,1
blezals $1,label
nop
nop


label:
nop
nop