data32={}
for i=1,32 do  
  data32[i]=2^(32-i)  
end  
--十进制转二进制  下标为 [1:32]  高位是1，和指令集相反
function d2b(arg)  
    local tr={}  
    for i=1,32 do  
        if arg >= data32[i] then 
          tr[i]=1  
          arg=arg-data32[i]  
        else  
          tr[i]=0  
        end  
    end  
    return tr  
end   --bit:d2b  
--二进制转十进制
function b2d(arg)  
    local nr=0  
    for i=1,32 do  
        if arg[i] ==1 then  
          nr=nr+2^(32-i)  
        end  
    end  
    return  nr  
end   --bit:b2d  

function rotr( rd, rt, sa)
  local val_rt = getgpr(rt)
  local op_rt = d2b(val_rt)
  local temp = {}
  local val_rd 

  if sa < 1 then    
    val_rd = val_rt
  else
    for i=1,sa do
      temp[i] = op_rt[32 - sa +i]
    end
    for i=sa+1,32 do
      temp[i] = op_rt[i - sa]
    end
    val_rd = b2d(temp)
  end
  setgpr(rd, val_rd)
end

register_instruction(
  'rotr $t1,$t2,10',
  'R',
  '000000 00001 sssss fffff ttttt 000010',
  rotr
)