data32 = {}
for i = 1, 32 do
	data32[i] = 2 ^ (32 - i)
end

function d2b(arg)
	local temp = arg
	local tr = {}
	if temp < 0 then
		temp = 2^32 + arg
	else
		temp = temp
	end

	for i = 1, 32 do
		if temp >= data32[i] then
			tr[i] = 1
			temp = temp - data32[i]
		else
			tr[i] = 0
		end
	end
	return tr
end

function b2d(arg)
	local nr = 0
	for i = 1, 32 do
		if arg[i] == 1 then
			nr = nr + 2 ^ (32 - i)
		end
	end
	return nr
end

function lhs(rt, imm, rs)
	local val_rs = getgpr(rs)
	local addr = val_rs + imm
	local binary = d2b(addr)
	local val_binary = {}
	local now_binary = {}
	local val
	local now_val
	if binary[32] == 0 then
		if binary[31] == 0 then
			val = loadw(addr)
			now_binary = d2b(val)
			for i = 17, 32 do
				val_binary[i] = now_binary[i]
			end
			for i = 1, 16 do
				val_binary[i] = val_binary[17]
			end
		else
			val = loadw(addr - 2)
			now_binary = d2b(val)
			for i = 17, 32 do
				val_binary[i] = now_binary[i - 16]
			end
			for i = 1, 16 do
				val_binary[i] = val_binary[17]
			end

		end
		val = b2d(val_binary)
		setgpr(rt, val)
	end


end

register_instruction(
  'lhs $t1,-100($t2)',
  'I',
  '011001 ttttt fffff ssssssssssssssss',
  lhs
)
