function blezals(rt, label)
	local val_rt = getgpr(rt)
	setgpr(31, getpc() + 4)
	if val_rt <= 0 then
		branch(label)
	end
end

register_instruction(
	'blezals $t1, label',
	'I_BRANCH',
	'011000 fffff 00000 ssssssssssssssss',
	blezals
)
